#ifndef REFERENCIAT_H
#define REFERENCIAT_H

void ref_putT(double ref);
double ref_getT(void);

#endif



