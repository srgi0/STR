#ifndef BUFDUPLO_H
#define BUFDUPLO_H

void bufduplo_insereLeitura (long leitura);
long *bufduplo_esperaBufferCheio (void);
int tamBuf (void);

#endif
