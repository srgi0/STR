#ifndef REFERENCIAN_H
#define REFERENCIAN_H

void ref_putN(double ref);
double ref_getN(void);

#endif



