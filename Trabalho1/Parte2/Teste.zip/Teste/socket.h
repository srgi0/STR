#ifndef SOCKET_H
#define SOCKET_H

void cria_socket(char *destino, int porta_destino);

double msg_socket(char * msg);

#endif
