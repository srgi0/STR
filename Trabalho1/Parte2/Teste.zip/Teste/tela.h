#ifndef TELA_H
#define TELA_H

void aloca_tela( void);

void libera_tela( void);

#endif
